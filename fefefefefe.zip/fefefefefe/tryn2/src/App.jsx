import "./App.css";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

function Home() {
  return (
    <div className="page">
      <h1>Discount -100% for Trip to North Korea</h1>
      <button>Get it now!</button>

      <h1>Tickets for planes:</h1>
      <p>China Xuanua: 12AM - EST</p>
      <p>China Xuanua: 12AM - EST</p>
      <p>China Xuanua: 12AM - EST</p>
      <p>China Xuanua: 12AM - EST</p>

      <p>Price for tickets: $200</p>

      <h1>Buy it on:</h1>
      <p>kakapuki.com</p>

      <div className="footer">
        <p>Тур-Агенство anex tours</p>
        <p>Пошта для рекомендацій: anextours@outlook.com</p>
      </div>
    </div>
  );
}

function About() {
  return (
    <div className="page">
      <h1>Про нас</h1>
      <p>Lorem ipsum dolor sit amet.</p>
    </div>
  );
}

function Contact() {
  return (
    <div className="page">
      <h1>Контакт</h1>
      <p>Lorem ipsum dolor sit amet.</p>
    </div>
  );
}

function Nav() {
  return (
    <nav className="nav">
      <img
        src="https://fta.travel/wp-content/uploads/2023/08/anex-logo.png"
        alt="Anex Tours logo"
      />
      <Link to="/">Main</Link>
      <Link to="/about">About Us</Link>
      <Link to="/contact">Contacts</Link>
    </nav>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Nav />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
